"""
Script to prepare JSON output for tidal sync servers from the list of hosts
"""
from machine_stats import main

main()
